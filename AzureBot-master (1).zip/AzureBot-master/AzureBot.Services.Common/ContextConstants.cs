﻿namespace AzureBot
{
    public class ContextConstants
    {
        public const string SubscriptionIdKey = "subscriptionId";
    }
}