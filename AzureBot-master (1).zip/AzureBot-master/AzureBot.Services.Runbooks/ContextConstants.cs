﻿namespace AzureBot
{
    public class AutomationContextConstants
    {
        public const string RunbookFormStateKey = "runbookFormState";

        public const string AutomationJobsKey = "automationJobsBySubscription";
    }
}