﻿namespace AzureBot.Forms
{
    using System;

    [Serializable]
    public enum Operations
    {
        Start = 1,
        Shutdown,
        Stop
    }
}